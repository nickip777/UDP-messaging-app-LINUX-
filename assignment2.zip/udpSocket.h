#ifndef UDPSOCKET_H
#define UDPSOCKET_H

void createSocket();
void sendMsg(char * msg);
char * receiveMsg();

#endif /* USPSOCKET_H */